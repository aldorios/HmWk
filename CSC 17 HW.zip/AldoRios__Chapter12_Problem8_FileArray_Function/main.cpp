
#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace std;

void Arraytofile(fstream,string ,int, int );

int main(int argc, char** argv) 
{
    fstream filebinary;
    string namefile;

    char* ptr;
   
    
    const int size = 100;
    char array[size]={'h','e','l','l','o',' ',
                      't','h','i','s',' ','i',
                      's',' ','t','h','e',' ', 
                      't','e','s','t',' ','f',
                      'o','r',' ','t','h','e',
                      ' ','n','e','x','t',' ',
                      'a','s','s','i','g','m',
                      'e','n','t',' ','t','h',
                      'a','t',' ','I',' ','h',
                      'a','v','e',' ','t','o',
                      ' ','d','o'};
    
    ptr = &array[size];
    
    
    cout <<"Enter the filename" << endl;
    cin >> namefile;   
    
    Arraytofile(filebinary, namefile, *ptr, size);
      
    
    return 0;
}

void Arraytofile(fstream filebinary,string namefile,int* ptr, int size)
{
    int i;
    
    filebinary.open(namefile.c_str(), ios :: binary); 
    
    while( i < size )
    {
     filebinary << &ptr[i];
        i++;
    }
    
  
    filebinary.close();

}