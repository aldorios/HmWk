
#include <iostream>
using namespace std;

int main ()
{
  int i,n,a;
  int * p;
  bool swap;
  int temp;
  a = 0;
  
  cout << "How many test grades would you like to type? ";
  cin >> i;
  p= new (nothrow) int[i];

    for (n=0; n<i; n++)
    {
      cout << "Enter grade: ";
      cin >> p[n];
      a += p[n];
    }
      
    cout << "You have entered: ";
    for (n=0; n<i; n++){
    cout << p[n] << ", ";
    }  
    cout << endl;
  
      do
    {
        swap = false;
        for (int count = 0; count < (i - 1); count++)
        {
            if(p[count] > p[count+1])
            {
                temp = p[count];
                p[count] = p[count+1];
                p[count+ 1] = temp;
                swap = true;
            }
        }
    }
    
    while(swap);
    
    
    
    cout <<" Sorted grades ";
   
     for(int swaped = 0;swaped < i;swaped++)
   {  
         cout << p[swaped];
   }
    a=a/i;
     cout << endl;
    cout << "the average is"<< a << endl;
            
         delete[] p;
    
  return 0;
}