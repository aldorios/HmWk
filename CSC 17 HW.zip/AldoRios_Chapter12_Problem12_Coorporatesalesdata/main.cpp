
#include<iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;
 
struct Division
{
  float firstqtr;
  float secondqtr;
  float thirdqtr;
  float fourthqtr;
  float annualsales;
  float average;
 
};
 
 
 
int main()
{
    Division north;
    Division south;
    Division west;
    Division east;
 
    char answer;
    int size = 4;
 
    for(int i = 0; i < size; i++)
    {
 
    cout << "Enter the first letter of your division:";
    cin >> answer;
 
    switch(answer)
    { // start for
    case 'n':
 
    	cout <<" What was the first quarter sales?" << endl;
    	cin >> north.firstqtr;
    	cout <<" What was the second quarter sales?" << endl;
    	cin >> north.secondqtr;
    	cout <<" What was the third quarter sales?" << endl;
    	cin >> north.thirdqtr;
    	cout <<" What was the fourth quarter sales?" << endl;
    	cin >> north.fourthqtr;
 
    	north.average = north.firstqtr + north.secondqtr +
    			north.thirdqtr + north.fourthqtr / 4;
 
    	north. annualsales= north.firstqtr + north.secondqtr +
    			north.thirdqtr + north.fourthqtr;
 
 
     break;
 
    case 's':
 
    	cout <<" What was the first quarter sales?" << endl;
    	cin >> south.firstqtr;
    	cout <<" What was the second quarter sales?" << endl;
    	cin >> south.secondqtr;
    	cout <<" What was the third quarter sales?" << endl;
    	cin >> south.thirdqtr;
    	cout <<" What was the fourth quarter sales?" << endl;
    	cin >> south.fourthqtr;
 
    	south.average = south.firstqtr + south.secondqtr +
        			south.thirdqtr + south.fourthqtr / 4;
 
        south.annualsales= south.firstqtr + south.secondqtr +
        			south.thirdqtr + south.fourthqtr;
 
     break;
 
    case 'w':
 
    	cout <<" What was the first quarter sales?" << endl;
    	cin >> west.firstqtr;
    	cout <<" What was the second quarter sales?" << endl;
    	cin >> west.secondqtr;
    	cout <<" What was the third quarter sales?" << endl;
    	cin >> west.thirdqtr;
    	cout <<" What was the fourth quarter sales?" << endl;
    	cin >> west.fourthqtr;
 
    	west.average = west.firstqtr + west.secondqtr +
        			west.thirdqtr + west.fourthqtr / 4;
 
        west.annualsales= west.firstqtr + west.secondqtr +
        			west.thirdqtr + west.fourthqtr;
     break;
 
    case 'e':
 
    	cout <<" What was the first quarter sales?" << endl;
    	cin >> east.firstqtr;
    	cout <<" What was the second quarter sales?" << endl;
    	cin >> east.secondqtr;
    	cout <<" What was the third quarter sales?" << endl;
    	cin >> east.thirdqtr;
    	cout <<" What was the fourth quarter sales?" << endl;
    	cin >> east.fourthqtr;
 
    	east.average = east.firstqtr + east.secondqtr +
        			east.thirdqtr + east.fourthqtr / 4;
 
        east.annualsales= east.firstqtr + east.secondqtr +
        			east.thirdqtr + east.fourthqtr;
     break;
 
 
    }
 
    } // end for
 
    cout <<setw(15)  <<"Average" << setw(30) <<"Annual Sales" << endl;
    cout << "North:  " <<north.average <<setw(30) << north.annualsales  << endl;
    cout << "South:  " <<south.average <<setw(30) << south.annualsales  << endl;
    cout << "East:   "<<east.average    <<setw(30) << east.annualsales  << endl;
    cout << "West:   " <<west.average   <<setw(30) << west.annualsales  << endl;
 
   return 0;
}
 

