
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;


int main(int argc, char** argv) {
    
    
    fstream file1;
    fstream file2;
    string name1;
    string name2;
    int size = 100;
    char array[size];
    int i =0;

    cout <<"Enter the name of a file you want to use "<< endl;
    cin >> name1;
    cout <<"Enter the name of the second file you want to use "<< endl;
    cin >> name2;    
    
    file1.open(name1.c_str(), ios :: out); // this will put the info to test
    
    file1 << "ProgramMing ChaLlenge. " << endl;
    file1 << "ProBlem 7 chapTer 9. " << endl;
      
    file1.close();
    
    file1.open(name1.c_str(), ios :: in); 
 

    while( !file1.eof())
    {
         file1 >> array[i];
         i++;
    }
    
  file1.close(); // close file

  file2.open(name2.c_str(),ios::out);

  for(int k = 0; k < i-1; k++)
  {
      tolower(array[k]);
      file2 << array[k];
  }

      file2.close();
    
      return 0; 
}

