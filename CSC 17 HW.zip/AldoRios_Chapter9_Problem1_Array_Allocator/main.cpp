
#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    int size = 0;
    int array[size];
    int* ptr;
    
    
    ptr = array[size];
    
    cout <<"How many elements would you like to save"<< endl;
    cin >> size;
    
    cout << &ptr;
    
    
    return 0;
}

