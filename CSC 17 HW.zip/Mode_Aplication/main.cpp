
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

int main(int argc, char** argv) {

    srand(time(0));
    const int size = 50;
    int array[size];
    int i,j;
    int swapholder = -1;
    bool swap;
    int temp;
    int mean = 0;
    int mode =0;

   for(i = 0;i < size;i++)
   {  
       int random = rand()%10;
       array[i]= random;
            
       mean += random;
   }
    
    cout <<"random numbers without sorting"<< endl;
   
   for(j = 0;j < size;j++)
   {  
         cout << array[j];
   }
    cout << endl;
    cout <<"________________________________________" << endl;
    cout << endl;
    cout <<" sorted numbers"<< endl;
        
    do
    {
        swap = false;
        for (int count = 0; count < (size - 1); count++)
        {
            if(array[count] > array[count+1])
            {
                temp = array[count];
                array[count] = array[count+1];
                array[count+ 1] = temp;
                swap = true;
            }
        }
    }
    
    while(swap);
    
   for(int swaped = 0;swaped < size;swaped++)
   {  
         cout << array[swaped];
   }
       
    mean = mean/50;
    
    cout << endl;
    cout <<"mean "<<mean<<endl;
    cout <<"median "<<array[25] << endl;
    return 0;
}
